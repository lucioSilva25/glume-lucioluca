import React from 'react'
import { View, Text, Button } from 'react-native'
const Home = ({navigation}) => {
    return (
        <View>
            <Button
                title='Crear Cuenta'
                onPress = {()=>{navigation.navigate('SignUp')}}
            />
            <Button
                title='Ir a mi perfil'
                onPress = {()=>{navigation.navigate('Profile')}}
            />
        </View>
    )
}

export default Home