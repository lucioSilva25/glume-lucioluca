import React from 'react';
import { Box, Heading, VStack, FormControl, Input, Button, Center, NativeBaseProvider } from "native-base";

const LinearGradient = require('expo-linear-gradient').LinearGradient;

const ejemplos = ({navigation}) => {
    
  return(

    <Box> hola
    </Box>
  )
  
  
};





export default ejemplos=({navigation}) => {
    return (
      <NativeBaseProvider>
        <Center flex={1} px="3">
            <ejemplos navigation={navigation}/>
        </Center>
      </NativeBaseProvider>
    );
};


