import React from 'react'
import { View,Text, Button, Dimensions,} from 'react-native'
import {
    LineChart,
    BarChart,
    PieChart,
    ProgressChart,
    ContributionGraph,
    StackedBarChart } from "react-native-chart-kit";
  const pantalla1 = ({navigation}) => {
    const data = {
        labels: ["January", "February", "March", "April", "May", "June"],
        datasets: [
          {
            data: [
              Math.random() * 100,
              Math.random() * 100,
              Math.random() * 100,
              Math.random() * 100,
              Math.random() * 100,
              Math.random() * 100
            ]
          }
        ]
      }

      const chartConfig = {
        
        backgroundColor: "#F34D5",
        
        color: (opacity = 0) => `rgba(	153,255,153, ${opacity})`,
        strokeWidth: 5, // optional, default 3
        barPercentage: 0.5,
        useShadowColorFromDataset: false // optional
      };

      const data1 = {
        labels: ["Swim", "Bike", "Run"], // optional
        data: [0.4, 0.6, 0.8]
      };

    return (
        <View>
        <Text>Bezier Line Chart</Text>
        
        
       
        
        <LineChart
  data={data}
  width={Dimensions.get('window').width}
  height={220}
  chartConfig={chartConfig}
/>
<ProgressChart
  data={data1}
  width={Dimensions.get('window').width}
  height={220}
  strokeWidth={16}
  radius={32}
  chartConfig={chartConfig}
  hideLegend={false}
/>


      </View>
    )
}




export default pantalla1