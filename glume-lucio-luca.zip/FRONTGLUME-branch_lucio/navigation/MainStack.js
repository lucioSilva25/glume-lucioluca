import { createNativeStackNavigator } from '@react-navigation/native-stack'
import React from 'react'
import {NavigationContainer} from '@react-navigation/native'
import Profile from '../Screens/Profile'; 
import SignUp from '../Screens/SignUp';
import Home from '../Screens/Home';
import pantalla1 from '../Screens/pantalla1';
import ejemplos from '../Screens/ejemplos';

const Stack = createNativeStackNavigator();

const MainStack = () => {
    return(
                <Stack.Navigator >

                    

                    <Stack.Screen
                        name = 'SignUp'
                        component = {SignUp}
                    />
                    <Stack.Screen
                        name = 'Profile'
                        component = {Profile}
                    />

                    <Stack.Screen
                        name = 'Home'
                        component = {Home}
                    />

                    <Stack.Screen
                        name = 'pantalla1'
                        component = {pantalla1}
                    />
                    
                    <Stack.Screen
                        name = 'ejemplos'
                        component = {ejemplos}
                    />
                    
                 
                </Stack.Navigator>
    )
}

export default MainStack