import React from 'react'
import { View, Text, Button } from 'react-native'
const Home = ({navigation}) => {
    return (
        <View>
            <Button
                title='Ir a mi perfil'
                onPress = {()=>{navigation.navigate('SignUp')}}
            />
        </View>
    )
}

export default Home